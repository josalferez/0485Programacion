public class ejercicio9{
	public static void main ( String[] args ) {
		// Declaro una variable de tipo entero y 
		// le asigno el valor decimal 18
		long edad = 132453934523453425L;
		
		System.out.printf("Mi edad es %d \n", edad);
		edad = 42345454325L;
		
		System.out.printf("Mi edad es %d \n", edad);
		
	}	
}