public class ejercicio5{
	public static void main ( String[] args ) {
		System.out.print("\033[33m mandarina \n");
		System.out.print("\033[32m hierba \n");
		System.out.print("\033[31m tomate \n");
		System.out.print("\033[37m sábanas \n");
	}	
}