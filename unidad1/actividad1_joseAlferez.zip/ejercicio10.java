public class ejercicio10{
	public static void main ( String[] args ) {
		// Declaro dos variables de tipo double y 
		// le asigno valores
		
		double x = 7;
		double y = 26.01;
		
		System.out.println("x vale " + x);
		System.out.println("y vale " + y);
	}	
}