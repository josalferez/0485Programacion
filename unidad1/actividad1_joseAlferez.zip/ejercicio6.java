public class ejercicio6{
	public static void main ( String[] args ) {
		System.out.println("| Codigo | Color | Codigo | Color");
		System.out.print("| \033[33m amarillo \033[39;49m |");

	}	
}