
public class ejercicio1 {
	public static void main(String[] args) {
		System.out.println("Hola mundo");
		if (true) {
			System.out.println("Esto está dentro del if");
		}
		System.out.println("Fin del programa");
	}
}

