public class ejercicio11 {
	public static void main ( String[] args) {
		String palabra = "bicicleta";
		String frase = "¿Donde esta mi bicicleta?";
		
		System.out.println("Una palabra que uso con frecuencia es: " + palabra);
		System.out.println("Una frase que uso a veces es: " + frase);
	}
}